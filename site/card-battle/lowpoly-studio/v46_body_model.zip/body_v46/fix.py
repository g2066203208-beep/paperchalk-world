import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import numpy as np,json
from pathlib import Path
from scipy.optimize import least_squares
from collections import Counter
P=Path('/mnt/data');O=P/'body_v46';d=json.load(open(P/'body_v45/data.json'));V=np.array(d['positions']);Q=np.array(d['polygons']);T=np.array(d['triangles']);M=np.load(O/'mirror.npy')
# Keep hip envelope and all nonlocal vertices. Shape continuous anterior thigh, especially transition to mid-thigh.
target={135:(0,1.4852,.200),136:(.123,1.492,.192),137:(.211,1.472,.117),138:(.239,1.472,-.007),139:(.203,1.472,-.126),140:(.112,1.471,-.181),141:(0,1.481,-.179),147:(0,1.415,.202),148:(.130,1.400,.196),149:(.236,1.392,.115),150:(.272,1.352,-.009),151:(.233,1.360,-.130),152:(.133,1.370,-.187),153:(0,1.409,-.183),163:(0,1.312,-.049),160:(.010,1.265,-.025),162:(.269,1.321,-.004),226:(.135,1.324,.188),227:(.0295,1.255,.153),228:(.032,1.255,-.097),229:(.145,1.297,-.146),230:(.232,1.322,-.112),231:(.234,1.326,.114),232:(.143,1.200,.158),233:(.026,1.227,.145),234:(.041,1.160,-.073),235:(.145,1.176,-.111),236:(.227,1.174,-.072),237:(.224,1.157,.099),396:(.250,1.141,.018),398:(.005,1.152,.050),238:(.118,1.016,.108),239:(.035,1.005,.076),243:(.186,1.015,.065),400:(.215,1.016,-.003)}
ids=list(target);idx=[(i,k) for i in ids for k in ([1,2] if M[i]==i else [0,1,2])];x0=np.array([target[i][k] for i,k in idx]);lim=np.array([min(.012,max(.001, target[i][0]*.5)) if k==0 else .016 if k==1 else .022 for i,k in idx]);
for j,(i,k) in enumerate(idx):
 if i in [135,136,137,138,139,140,141,153,163,160,398,228,234,238,239,243,400]:lim[j]*=.55
 if i in [150,162,396] and k==0:lim[j]=.006
active=np.array([f for f in Q if all(V[i,0]>=-1e-8 for i in f) and any(i in ids for i in f)]);u=lambda a:a/np.maximum(1e-12,np.linalg.norm(a,axis=-1,keepdims=True))
def pos(x):
 p=V.copy()
 for (i,k),v in zip(idx,x):p[i,k]=v
 for i in ids:p[M[i]]=p[i]*[-1,1,1]
 return p
# longitudinal face pairs, not across anatomical folds. No hard shading at the hip/thigh junction.
pairs=[(124,252),(125,253),(126,254),(127,255),(128,256),(129,257),(252,260),(253,261),(254,262),(255,263),(256,264),(257,265),(260,268),(261,269),(262,270),(263,271),(264,272)]
chains=[[136,148,226,232,238],[137,149,231,237,243],[138,150,162,396,400],[140,152,229,235,241]]
def normals(p):
 a=p[Q];return u(np.sum(np.cross(a,np.roll(a,-1,axis=1)),axis=1))
def res(x):
 p=pos(x);a=p[active];n1=u(np.cross(a[:,1]-a[:,0],a[:,2]-a[:,0]));n2=u(np.cross(a[:,2]-a[:,0],a[:,3]-a[:,0]));n3=u(np.cross(a[:,2]-a[:,1],a[:,3]-a[:,1]));n4=u(np.cross(a[:,3]-a[:,1],a[:,0]-a[:,1]));cos=(u(np.roll(a,1,axis=1)-a)*u(np.roll(a,-1,axis=1)-a)).sum(-1);n=normals(p);diff=np.array([n[i]-n[j] for i,j in pairs]);sl=[]
 for ch in chains:
  a=p[ch];v=np.diff(a,axis=0);sl.extend(np.diff(u(v),axis=0).ravel())
 return np.r_[(n1-n2).ravel()*8,(n3-n4).ravel()*8,np.maximum(0,np.abs(cos)-.83).ravel()*3,(x-x0)/lim*.85,diff.ravel()*2.0,np.array(sl)*.9]
r=least_squares(res,x0,bounds=(x0-lim,x0+lim),max_nfev=240,ftol=1e-7);A=pos(r.x)
src=(P/'extreme_v3/make.py').read_text();exec(src[src.index('from numba import njit'):src.index('rest=np.array(bones)')]);crossings=int(intersect(A,T));E=Counter(tuple(sorted((a,b))) for f in Q for a,b in zip(f,np.roll(f,-1)));F={tuple(sorted(f)) for f in Q};ix=np.array([j for j,f in enumerate(Q) if any(i in ids or M[i] in ids for i in f)])
def measure(p):
 a=p[Q];w=np.degrees(np.arccos(np.clip((u(np.cross(a[:,1]-a[:,0],a[:,2]-a[:,0]))*u(np.cross(a[:,2]-a[:,0],a[:,3]-a[:,0]))).sum(-1),-1,1)));n=normals(p);ang=np.array([np.degrees(np.arccos(np.clip(n[i]@n[j],-1,1))) for i,j in pairs]);return {'localWarp':float(w[ix].max()),'bodyWarp':float(w[92:].max()),'longitudinalNormalJumpMax':float(ang.max()),'longitudinalNormalJumpMedian':float(np.median(ang)),'upperThighFrontDepth':float(p[232,2])}
stats={'before':measure(V),'after':measure(A),'vertices':len(A),'quads':len(Q),'sourceTriangles':sum(len(f)==3 for f in Q),'strictCrossings':crossings,'changedVertices':int(np.any(A!=V,axis=1).sum()),'mirrorError':float(np.abs(A[M]-A*[-1,1,1]).max()),'mirrorFaceErrors':sum(tuple(sorted(M[f])) not in F for f in Q),'nonmanifoldEdges':sum(v!=2 for v in E.values()),'euler':len(A)-len(E)+len(Q),'sameTopology':True};d['positions']=A.tolist();d['stats']=stats;json.dump(d,open(O/'data.json','w'));json.dump(stats,open(O/'audit.json','w'),indent=2);print(stats,flush=True)
