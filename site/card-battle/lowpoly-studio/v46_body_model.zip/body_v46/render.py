import numpy as np,json,shutil
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
from scipy.ndimage import distance_transform_edt
from numba import njit
P=Path('/mnt/data');O=P/'body_v46';d=json.load(open(O/'data.json'));V=np.array(d['positions']);Q=d['polygons'];T=np.array(d['triangles']);hn=92;old=d;E={tuple(sorted((a,b))) for f in Q for a,b in zip(f,f[1:]+f[:1])};stats=d['stats'];s=.00234;Y=lambda h:2.76766821951202-(h-26)*s
UV=np.array(d["uv"]);tex=np.array(Image.open(P/'head_v26/face.png').convert('RGB'));shutil.copy(P/'head_v26/face.png',O/'face.png');skin=np.array([255,222,205]);norm=[]
for f in Q:
 a=V[f];n=np.sum(np.cross(a,np.roll(a,-1,axis=0)),axis=0);norm.append(n/np.linalg.norm(n))
normal=np.array(norm);height=np.array([np.concatenate([np.load(P/"body_v33/before.npy"), V[428:]])[f].mean(0)[1] for f in Q]);sd=np.clip((.83-normal[:,2])/.83,0,1);rear=np.clip((.10-normal[:,2])/.65,0,1);backlo=np.clip((2.2573-height)/.115,0,1);base=skin-np.array([3,7,6])*sd[:,None]-np.array([28,52,46])*(backlo*rear)[:,None]
light=np.array([0,.5,1]);light/=np.linalg.norm(light);lightness=.92+.08*np.maximum(0,normal@light);base[hn:]=skin*lightness[hn:,None]-np.array([8,14,12])*(np.maximum(0,-normal[hn:,1]))[:,None];base[92:96]=np.array([249,213,197])*(.98+.02*np.maximum(0,normal[92:96]@light))[:,None];ids=((normal[:,2]>.20)&(height>1.95)).astype(int);ids[92:]=0;C=np.array([b/skin if j else b for j,b in zip(ids,base)]);CC=np.repeat(C,2,axis=0);II=np.repeat(ids,2);VV=V.copy();TT=T.copy();UU=UV.copy();EE=np.array(list(E));NN=np.repeat(normal,2,axis=0)
for m in old['modules'].values():
 p=np.array(m['positions']);t=np.array(m['triangles']);q=m['polygons'];off=len(VV);VV=np.concatenate([VV,p]);TT=np.concatenate([TT,t+off]);UU=np.concatenate([UU,np.zeros((len(p),2))]);EE=np.concatenate([EE,np.array(list({tuple(sorted((a,b))) for f in q for a,b in zip(f,f[1:]+f[:1])}))+off]);II=np.concatenate([II,np.zeros(len(t),int)]);CC=np.concatenate([CC,np.tile([238,187,174],(len(t),1))]);nn=p[t];n=np.cross(nn[:,1]-nn[:,0],nn[:,2]-nn[:,0]);n/=np.linalg.norm(n,axis=1)[:,None];NN=np.concatenate([NN,n]);
src=(P/'head_v9/build.py').read_text();exec(src[src.index('@njit\ndef raster'):src.index("colors={'body'")].replace('return im','return im,z'))
W,H=420,720;centery=(V[:,1].max()+V[:,1].min())/2;factor=250

def draw(angle,wire=False,white=False,pitch=0,ears=True):
 az=np.deg2rad(angle);el=np.deg2rad(pitch);f=np.array([np.sin(az)*np.cos(el),np.sin(el),np.cos(az)*np.cos(el)]);r=np.array([np.cos(az),0,-np.sin(az)]);u=np.cross(f,r);p=VV if ears else V;tris=TT if ears else T;edges=EE if ears else np.array(list(E));col=CC if ears else CC[:len(T)];mat=II if ears else II[:len(T)];uv=UU if ears else UV;norms=NN if ears else NN[:len(T)];pv=p-np.array([0,centery,0]);q=np.column_stack([W/2+pv@r*factor,H/2-pv@u*factor,pv@f]);
 if white:col=np.tile([239,237,234],(len(tris),1))*(.74+.26*np.maximum(0,norms@light))[:,None];mat=mat*0
 im,z=raster(q,col,tris,mat,uv,tex,wire,edges,W,H);mask=z>-1e8
 if not wire:
  alpha=np.clip(1.8-distance_transform_edt(~mask),0,1)*.92*(~mask);ink=np.array([144,100,95]) if not white else np.array([120,116,116]);im=(im*(1-alpha[:,:,None])+ink*alpha[:,:,None]).astype(np.uint8)
 return Image.fromarray(im)
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',16)
ref=Image.open(P/'q版人体三视图参考表.png').convert('RGB').resize((1408,1056));scale=(V[:95,1].max()-V[4:79,1].min())/255*factor
can=Image.new('RGB',(W*3,4*(H+26)),(247,246,246));dr=ImageDraw.Draw(can)
for i,a in enumerate([0,90,180]):
 im=draw(a);wire=draw(a,True,True,ears=False);im.save(O/f'model-{i}.png');wire.save(O/f'wire-{i}.png');cx=[347,728,1125][i];crop=ref.crop((cx-170,70,cx+170,980));crop=crop.resize((round(340*scale),round(910*scale)),Image.Resampling.LANCZOS);refim=Image.new('RGB',(W,H),(247,246,246));refim.paste(crop,((W-crop.width)//2,round(H/2-(V[4:79,1].min()+(355-70)*scale/factor-centery)*factor)));refim.save(O/f'ref-{i}.png')
 for j,img in enumerate([refim,im,Image.blend(im,refim,.45),wire]):
  can.paste(img,(W*i,(H+26)*j+26));dr.text((W*i+8,(H+26)*j+4),['FRONT','SIDE','BACK'][i]+' / '+['NEW REFERENCE','ACTUAL MESH','45% REFERENCE','SOURCE QUADS'][j],font=font,fill='#38313a')
can.save(P/'v46_body_comparison.png');draw(35,pitch=4).save(P/'v46_body_threequarter.png')
frames=[draw(a).resize((280,480)) for a in range(0,360,15)];frames[0].save(P/'v46_body_turntable.gif',save_all=True,append_images=frames[1:],duration=90,loop=0,optimize=True)
obj=['mtllib body.mtl','o continuous_body']+['v '+' '.join(map(str,p)) for p in V]+['vt '+' '.join(map(str,p)) for p in UV];last=None
for f,n in zip(Q,ids):
 m='face' if n else 'skin'
 if m!=last:obj.append('usemtl '+m);last=m
 obj.append('f '+' '.join(f'{i+1}/{i+1}' for i in f))
off=len(V)
for k,m in old['modules'].items():
 obj.extend(['o '+k,'usemtl skin']);obj.extend('v '+' '.join(map(str,p)) for p in m['positions']);obj.extend('f '+' '.join(str(i+1+off) for i in f) for f in m['polygons']);off+=len(m['positions'])
(O/'body.obj').write_text('\n'.join(obj));(O/'body.mtl').write_text('newmtl skin\nKd 1 .87 .80\nnewmtl face\nKd 1 1 1\nmap_Kd face.png\n');print(stats,flush=True)
