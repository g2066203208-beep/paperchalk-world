Real 16 Photoshop layers and exact split into 17 independent ArtMeshes. No invented legs / back.
