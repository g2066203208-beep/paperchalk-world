Male2 split from seethrough-bebdb7ca8778-layers.zip
16 genuine components; 8 blank categories skipped.
No artificial back side. Hands share one original layer.
Source archive SHA256: 3ecc95e4b50d9302a0926a15ce51ec146a42230a1da96782c2ed71d2bdf684c9
